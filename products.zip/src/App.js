
import './App.css';
import CreateProduct from './components/CreateProduct';
import Login from './components/Login';
import List from "./components/List"
import{BrowserRouter,Route,Routes,Link} from 'react-router-dom';

function App() {
  return (
    <div className="App">

    <Login/> 
    <BrowserRouter>
    <ul>
      <li>
        <Link to="/CreateProduct">CreateProduct</Link>
        <Link to="/List">List</Link>
      </li>
    </ul>
      <Routes>
      <Route path="/createProduct" element={<CreateProduct/>}/>
    <Route  path="/List" element={<List/>}/>
      </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;

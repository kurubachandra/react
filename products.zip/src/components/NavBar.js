import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import

function NavBar() {
  return (
    <div>
      <BrowserRouter>
      <Routes>
      <Route>
      
      </Route>
      </Routes>
      </BrowserRouter>
    </div>
  )
}

export default NavBar

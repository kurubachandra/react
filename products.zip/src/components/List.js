import React, {useState } from 'react'
import { db } from "../firebase-configure";
import {useNavigate} from 'react-router-dom'
import { useEffect } from 'react';
import {collection, getDocs} from "firebase/firestore"
function List() {
    const [products, setProducts] = useState([]);
    // const[pid,setPId]=useState();
    // const[pname,setPname]=useState();
    // const[quantity,setQuantity]=useState();
    // const[price,setPrice]=useState();
    const ref = collection(db, "product")
    // useEffect(() => {
    //     const snapshot=ref.get();
    //     snapshot.forEach(doc => {
    //         console.log(doc.id,'=>',doc.data());

    //     });
    // }, []);
    const getBoards = async () => {
        const data = await getDocs(ref);
        setProducts(data.docs.map((doc) => ({ ...doc.data(), id: doc.id })))
    };
    // const navigate = useNavigate();
    useEffect(() => {
        getBoards();
    }, []);
    return (
        <div className='container'>
            <h1>Prouct List</h1>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Id</th>
                        <th scope="col">Name</th>
                        <th scope="col">quantity</th>
                        <th scope="col">Price</th>
                    </tr>
                </thead>
                <tbody>
                    { 
                    products.map(product => {
                        return (<tr key={product.id}>
                            <th scope="col">{product.id}</th>
                            <th scope="col">{product.name}</th>
                            <th scope="col">{product.quantity}</th>
                            <th scope="col">{product.price}</th>
                        </tr>
                        )
                    })}
                </tbody>
            </table>
        </div>

    )
}
export default List;
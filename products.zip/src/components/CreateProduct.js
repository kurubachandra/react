import React, { useState ,useNavigate} from 'react'
import { db } from "../firebase-configure"
import { collection, addDoc } from "firebase/firestore";

function CreateProduct() {

    const ref = collection(db, "product");
    const [id, setId] = useState();
    const [name, setName] = useState();
    const [quantity, setQunatity] = useState();
    const [price, setPrice] = useState();
    const handleCreateProducts = (e) => {
        e.preventDefault();


        addDoc(ref, { id, name, quantity, price });
        alert("successfully product added........");
        
    }



    return (
        <div className='container'>
            <div >
                <h1>Product Details</h1>
                <hr/>

            <form className="row g-3">
                <div className="row-md-6">
                    <label htmlFor="inputpId" className="form-label">ProductId</label>
                    <input type="Id" className="form-control" id="inputId" placeholder='Id' onChange={(e) => setId(e.target.value)} />
                </div>
                <div className="row-md-6">
                    <label htmlFor="inputpName" className="form-label">ProductName</label>
                    <input type="text" className="form-control" id="inputName" placeholder='Name' onChange={(e) => setName(e.target.value)} />
                </div>
                <div className="row-3">
                    <label hmtlFor="inputQuantity" className="form-label">Quantity</label>
                    <input type="number" className="form-control" id="inputQuantity" placeholder="Quantity" onChange={(e) => setQunatity(e.target.value)} />
                </div>
                <div className="row-3">
                    <label htmlFor="inputPrice" className="form-label">Price</label>
                    <input type="Number" className="form-control" id="inputPrice" placeholder="price" onChange={(e) => setPrice(e.target.value)} />
                </div>

                <div className="row-12">
                    <button onClick={handleCreateProducts} className="btn btn-primary">submit</button>
                </div>
            </form>
            {id}{name}
            </div>
        </div>
    )
}

export default CreateProduct

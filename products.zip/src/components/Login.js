import { addDoc, collection } from 'firebase/firestore';
import React, { useState } from 'react'
import { db } from "../firebase-configure"

function Login() {
    const [email, setEmail] = useState();
    const [password, setPassword] = useState();
    const ref = collection(db, "login");
    const handlelogin = async(e) => {
        e.preventDefault();
       await addDoc(ref, ({ email, password }));
        alert("login Successful")

    }

    return (
        <div className='container'>
            <h1>Login From</h1>
            <hr/>
            <form className="row g-3">
                <div className="row-md-6">
                    <label htmlFor="inputEmail4" className="form-label">Email</label>
                    <input type="email" className="form-control" id="inputEmail4" placeholder='Email' value={email} onChange={(e)=> setEmail(e.target.value)} />
                </div>


                <div className="row-md-6">
                    <label htmlFor="inputPassword4" className="form-label">Password</label>
                    <input type="password" className="form-control" id="inputPassword4" placeholder='Password' value={password} onChange={(e)=> setPassword(e.target.value)}/>
                </div>

                <div className="col-12">
                    <button onClick={handlelogin} className="btn btn-primary">Sign in</button>
                </div>
            </form>
        </div>
    )
}

export default Login

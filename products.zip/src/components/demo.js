a=20;
console.log(a);
var a=20;
console.log(a);

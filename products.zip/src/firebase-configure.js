
import { initializeApp } from "firebase/app";
import {getFirestore} from "@firebase/firestore";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCZsRaqVtZzHmWI9X77LCOlDm853Vz0T5E",
  authDomain: "fire-base-34efe.firebaseapp.com",
  projectId: "fire-base-34efe",
  storageBucket: "fire-base-34efe.appspot.com",
  messagingSenderId: "869306929686",
  appId: "1:869306929686:web:173809e75f81a9ef929b37"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
 const db=getFirestore(app);
export{db};
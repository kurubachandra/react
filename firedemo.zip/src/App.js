
import './App.css';
import Create  from './components/Create';
import {db} from './FireBase';


function App() {
  return (
  <div>
<Create/>

    </div>
  );
}

export default App;

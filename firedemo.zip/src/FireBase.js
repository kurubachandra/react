// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
0
import{getFireStore} from "@firebase/firestore";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyA6dsiVBssrkP-k5IlI6UzcKEVKZF27q64",
  authDomain: "firedemo-1c0fb.firebaseapp.com",
  projectId: "firedemo-1c0fb",
  storageBucket: "firedemo-1c0fb.appspot.com",
  messagingSenderId: "784739147902",
  appId: "1:784739147902:web:bd9d72cd86392ea2c3f82f",
  measurementId: "G-FTRKP2TL6Y"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const db =getFireStore(app)
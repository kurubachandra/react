import React ,{useState}from 'react'

import{db} from "./firebase";
import{collection } from "./firebase";
function Create() {
  const[users,setUsers]=useState();
  const usersCollectionsRef=collection(db,"users")
  useEffect(() => {
    
    const getUsers=async()=>{
      const data=await getDocs(usersCollectionsRef)

    }
    getUsers()
    return () => {
      
    };
  }, [input]);

  return (
    <div>
      
    </div>
  )
}

export default Create

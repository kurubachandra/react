import React, { useEffect, useState } from 'react'
import StoreServices from '../services/StoreServices';

function Store() {
  const [store, setStore] = useState([]);

  useEffect(() => {
    getAllStore();
  }, []);

  const getAllStore = async () => {
    const res = await StoreServices.getAllStore();
    console.log(res.data);
    setStore(res.data);

  }
  return (
   
       
    <div className='container-fluid'>
       <h1>FlipkartfakeApistore</h1>
    <div className="row" >
        <div className="card-group">
          
            {store.map((item) => {
                return (
                    <div className='col-3 mb-2' >
                        <div className="card" style={{ height: "32rem", width: "24rem" }}>
                            <div class="card-header">
                                <p className="card-text"><b>Category :{item.category}</b></p>
                            </div>
                            <img src={item.image} className="card-img-top" alt="Network Issue" id="imagecard" />
                            <div className="card-body">
                                <p className="card-title"> <b>Title :</b>{item.title}</p>
                                {/* <p className="card-text"><b> Description :</b>{res.description}</p> */}
                            </div>
                            <div class="card-footer text-muted d-flex justify-content-between">
                                <p><b>Rate :{item.rating.rate}</b></p>
                                <p className="card-text"><b>Count :{item.rating.count}</b></p>
                                <p><b>Price :{item.price}</b></p>
                            </div>
                        </div>
                    </div>
                )
            })}
        </div>



   </div>
</div>
)
}
        



export default Store;

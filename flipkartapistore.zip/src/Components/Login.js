import React, {useState,useEffect}from 'react'
import { useNavigate } from 'react-router-dom';
import StoreServices from '../services/StoreServices';

function Login() {
    const[email,setEmail]=useState();
    const[password,setPassword]=useState();
   
       const navi= useNavigate();
      const[luser,setLuser]=useState([]);
      const getuserdetails=async(e)=>{
        const userdata=await StoreServices.getAlldata();
        setLuser(userdata.data);
        console.log("user-list:"+JSON.stringify(luser));
      }
      useEffect(() => {
        getuserdetails();
        
      }, []);
      function login(){
        luser.filter((stm)=>{
            console.log("map data:"+JSON.stringify(stm));
            if(stm.email==email&&stm.password==password){
                navi("/store");
                alert("login sucess.........")
            }
            else{
              alert("enter valid email and password")
            }
        })
      }
  return (
    <div className='container'>
        <div className='chandu'>
         <h1>Login Form</h1>
            <hr />
            <form class="changing-border">
                <div clasName="mb-3">
                    <label htmfor="inputid" className="form-label">Email</label>
                    <input type="text" className="form-control" id="inputemail"   placeholder="Enter your Pass"
                            value={email}onChange={(e) => setEmail(e.target.value)} />
                </div>
                <div className="mb-3">
                    <label htmfor="inputName" className="form-label">Password</label>
                    <input type="Password" className="form-control" id="inputPassword"   placeholder="Enter your Pass"
                            value={password}onChange={(e) => setPassword(e.target.value)} />
                </div>
              
                
                <div className="text-center">
                    <button type="submit"className="btn btn-primary" onClick={login}>Signin</button>
                    {/* <a className='btn btn-primary'>Forgot Password</a> */}
                </div>
                </form>
                {email}{password}
      </div>
    </div>
  )
}

export default Login

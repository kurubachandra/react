import React, { useState } from 'react'
import { Navigate } from 'react-router-dom';
import StoreServices from '../services/StoreServices';

function Register() {
    const[id,setId]=useState();
    const [username, setUserName] = useState();
    const [email, setEmail] = useState();
    const [password, setPassword] = useState();
    const[pincode,setPinocde]=useState();
    const[city,setCity]=useState();
  const registerStore=(e)=>{

  
        let obj = {
            "id":parseInt(id),
            "username": username,
            "email": email,
            "password": password,
            "pincode":pincode,
            "city":city

        };
        StoreServices.registerStore(obj).then((res)=>{})
Navigate("/Login")
}
    return (

        <div className='container'>
 
            <h1>Register Form</h1>
            <hr />
            <form class="row g-3">
            <div clasName="col-md-3">
                    <label htmfor="inputid" className="form-label">Id</label>
                    <input type="text" className="form-control" id="inputid" value={id} onChange={(e) => setId(e.target.value)} />
                </div>




                <div clasName="col-md-3">
                    <label htmfor="inputUserName" className="form-label">username</label>
                    <input type="text" className="form-control" id="inputUserName" value={username} onChange={(e) => setUserName(e.target.value)} />
                </div>
                <div className="row-md-3">
                    <label htmfor="inputEmail" className="form-label">Email</label>
                    <input type="text" className="form-control" id="inputName"  value={email} onChange={(e) => setEmail(e.target.value)} />
                </div>
                <div className="row-md-3">
                    <label htmfor="inputpassword" className="form-label">Password</label>
                    <input type="Password" className="form-control" id="inputPassword"  value={password} onChange={(e) => setPassword(e.target.value)} />
                </div>
                <div className="row-md-3">
                    <label htmfor="inputpincode" className="form-label">Pincode</label>
                    <input type="text" className="form-control" id="inputPincode"value={pincode} onChange={(e) => setPinocde(e.target.value)} />
                </div>
                <div className="row-md-3">
                    <label htmfor="inputcity" className="form-label">City</label>
                    <input type="text" className="form-control" id="inputCity" value={city} onChange={(e) => setCity(e.target.value)} />
                </div>


                <div className="col-12">
                    <button onClick={registerStore} className="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>


    )
}

export default Register;

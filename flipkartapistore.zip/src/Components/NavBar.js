import React from 'react'
import { BrowserRouter, Route, Routes, Link } from "react-router-dom"
import Login from './Login'
import Register from './Register'
import Store from './Store'

   function NavBar(){
        return (
            <div className='App'>
                <BrowserRouter>
                    <ul>
                    <li><Link to="/">Home</Link></li>
                        <li><Link to="/login"className="text-decoration-none">SignIn</Link></li>
                        <li><Link to="/register"  className="text-decoration-none">SignUp</Link></li>
                        
                        
                    </ul>
                    <Routes>
                    <Route path="/" element={<Store />} />
                        <Route path="/store" element={<Store />} />
                        <Route path="/login" element={<Login />} />
                        <Route path="/register" element={<Register />} />
                    </Routes>
                </BrowserRouter>

            </div>
        );
    }

export default NavBar

import axios from "axios";
const baseUrl  ="http://localhost:3000/storeList";
 class Register{
    createUserDetails(User){
        return axios.post(baseUrl,User);
    }
  getUser(){
    return axios.get(baseUrl);
  }

 }
 export default from new Register();
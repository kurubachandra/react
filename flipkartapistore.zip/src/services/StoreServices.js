import axios from "axios"
const baseUrl="https://fakestoreapi.com/products"
class StoreServices{
    getAllStore(){
        return axios.get(baseUrl);
        
    }
    registerStore (data){
        return axios.post("http://localhost:3000/storeList",data);
    }
getAlldata(){
    return axios.get("http://localhost:3000/storeList");
}
}
export default  new StoreServices();

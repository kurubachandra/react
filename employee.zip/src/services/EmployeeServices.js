import axios from "axios";
const baseUrl="http://localhost:3001/employeeList";
class EmployeeServices{
    getAllEmployee(){
        return axios.get(baseUrl);
    }
    getEmployee(id){
        return axios.get(`${baseUrl}/${id}`);
    }
    deleteEmployee(id){
        return axios.delete(baseUrl+"/"+id);
    }
    updateEmployee(id){
        return axios.put(`${baseUrl}+${id}`,employee);
    }
    createEmployee(employee){
        return axios.post(baseUrl,employee);
    }



}
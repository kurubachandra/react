import React from 'react'

function EmployeeList() {
    const [Employee, setEmployees] = useState([]);
  return (
    <div className='conatiner'>
      <table className="table">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">Name</th>
      <th scope="col">Domain</th>
      <th scope="col">Salary</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>2202</td>
      <td>chandra</td>
      <td>java</td>
      <td>10000</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>2203</td>
      <td>prakash</td>
      <td>python</td>
      <td>15000</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td colspan="2">Larry the Bird</td>
      <td>@twitter</td>
    </tr>
  </tbody>
</table>
    </div>
  )
}

export default EmployeeList

import React from 'react'
import React,{useState} from 'react'; 
function RegisterEmployee() {
  const[username,setUserName]=useState();
  const[email,setEmail]=useState();
  const[password,setPassword]=useState();
  const[confirmpassword,setConfirmPassword]=useState();
  const[address,setAddress]=useState();
  const[address2,setAddress2]=useState();
  const[city,setCity]=useState();
  const[state,setstate]=useState();
  const[pincode,setPincode]=useState();


  return (
    <div>
      <form class="row g-3">
  <div class="row-md-3">
    <label htmlfor="inputUserName" className="form-label">UserName</label>
    <input type="text" className="form-control" id="UserName" placeholder='enter your username' onChange={(e)=>setUserName(e.target.value)}/>
  </div>
  <div className="row-md-3">
    <label htmlfor="inputEmail" className="form-label">Email</label>
    <input type="text" className="form-control" id="inputEmail" placeholder='enter a email' onChange={(e)=>setEmail(e.target.value)}/>
  </div>
  <div className="row-md-3">
    <label htmlfor="inputPassword" className="form-label">Password</label>
    <input type="Password" class="form-control" id="inputpassword" placeholder='enter a password' onChange={(e)=>setPassword(e.target.value)}/>
  </div>
  <div className="row-md-3">
    <label htmlfor="inputconfirmPassword" className="form-label">Confirm Password</label>
    <input type="confirmPassword" class="form-control" id="inputpassword" placeholder='enter a confrim password'onChange={(e)=>setConfirmPassword(e.target.value)}/>
  </div>
  <div className="row-3">
    <label htmlfor="inputAddress" className="form-label">Address</label>
    <input type="text" className="form-control" id="inputAddress" placeholder="1234 Main St"onChange={(e)=>setAddress(e.target.value)}/>
  </div>
  <div class="col-12">
    <label for="inputAddress2" class="form-label">Address 2</label>
    <input type="text" class="form-control" id="inputAddress2" placeholder="Apartment, studio, or floor"onChange={(e)=>setAddress2(e.target.value)}/>
  </div>
  <div class="col-md-6">
    <label for="inputCity" class="form-label">City</label>
    <input type="text" class="form-control" id="inputCity" placeholder='enter city'onChange={(e)=>setCity(e.target.value)}/>
  </div>
  <div class="col-md-4">
    <label for="inputState" class="form-label">State</label>
    <select id="inputState" class="form-select" >
      <option selected>Choose...</option>
      <option>AndhraPradesh</option>
      <option>Telengana</option>
      <option>kerala</option>
      <option>karnataka</option>
    </select>
  </div>
  <div class="col-md-2">
    <label htmlfor="inputpincode" className="form-label">Pincode</label>
    <input type="text" className="form-control" id="inputpincode" placeholder='enter a pincode'onChange={(e)=>setPincode(e.target.value)}/>
  </div>
  
   
 
  <div class="col-12">
    <button onClick={"submit"} class="btn btn-primary">Sign in</button>
  </div>
</form>
    </div>
  )
}

export default CreateEmployee

import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';

function Register() {

    const [email, setEmail] = useState("");
    const [username, setUserName] = useState("");
    const [password, setPassword] = useState("");
    const [cpass, setcPass] = useState("");
    const [address, setAddress] = useState("");
    const [address2, setAddress2] = useState("");
    const [city, setCity] = useState("");
    const [state, setState] = useState("");
    const [zipcode, setZipcode] = useState("");
    const navigate = useNavigate();






    var arr = [{}];
    let login = (e) => {
        var name = document.getElementById("inputEmail4");
        arr.push(email);
        var name = document.getElementById("inputUserName");
        arr.push(username);
        var name = document.getElementById("inputPassword4");
        arr.push(password);
        var name = document.getElementById("formGroupExampleInput4");
        arr.push(cpass);
        var name = document.getElementById("inputAddress");
        arr.push(address);
        var name = document.getElementById("inputAddress2");
        arr.push(address2);

        var name = document.getElementById("inputCity");
        arr.push(city);
        var name = document.getElementById("inputstate");
        arr.push(state);
        var name = document.getElementById("inputZip");
        arr.push(zipcode);
        console.log(arr);
    }





    const handleEmail = (e) => {
        setEmail(e.target.value);
    };

    const handleUserName = (e) => {
        setUserName(e.target.value);
    };
    const handlePassword = (e) => {
        setPassword(e.target.value);
    };
    const handleUserCPass = (e) => {
        setcPass(e.target.value);
    };
    const handleAddress = (e) => {
        setAddress(e.target.value);
    };
    const handleAddress2 = (e) => {
        setAddress2(e.target.value);
    };
    const handlecity = (e) => {
        setCity(e.target.value);
    };

    const handlestate = (e) => {
        setState(e.target.value);
    };
    const handleZipcode = (e) => {
        setZipcode(e.target.value);
    };






    return (



        <div className='chandu container border border-2 mt-5container border border-2 mt-5'>
            <h1>Registraction Form</h1>
            <form className="row g-2">
                <div className='mb-3'>
                    <div className="row-md-2">
                        <label htmfor="inputEmail4" className="form-label">Email</label>
                        <input type="email" className="form-control" id="inputEmail4" placeholder='main' onChange={handleEmail} />
                    </div>


                    <div className="row-md-3">
                        <label htmfor="inputUserName" className="form-label">UserName</label>
                        <input type="UserName" className="form-control" id="inputUserName" placeholder='UserName' onChange={handleUserName} />
                    </div>

                    <div className="row-md-3">
                        <label htmfor="inputPassword4" className="form-label">Password</label>
                        <input type="password" className="form-control" id="inputPassword4" placeholder='Password' onChange={handlePassword} />
                    </div>
                </div>
                <div className="mb-3">
                    <label htmfor="formGroupExampleInput2" className="form-label">Conform Password</label>
                    <input type="text" className="form-control" id="formGroupExampleInput4" placeholder="Conform Password" onChange={handleUserCPass} />
                </div>

                <div className="row-3">
                    <label htmfor="inputAddress" className="form-label">Address</label>
                    <input type="text" className="form-control" id="inputAddress" placeholder='Flat number' onChange={handleAddress} />
                </div>


                <div className="row-3">
                    <label htmfor="inputAddress2" className="form-label">Address 2</label>
                    <input type="text" className="form-control" id="inputAddress2" placeholder="Apartment, studio, or floor" onChange={handleAddress2} />

                </div>

                <div className="row-md-3">
                    <label htmfor="inputCity" className="form-label">City</label>
                    <input type="text" className="form-control" id="inputCity" placeholder="city" onChange={handlecity} />
                </div>


                <div className="row-md-3">
                    <label htmfor="inputState" className="form-label">State</label>
                    <input type="text" className="form-control" id="inputstate" placeholder='state' onChange={handlestate} />
                    <select id="inputState" className="form-select">
                         <option selected >choose</option>
                            <option>kerala</option>
                         <option>Andhra pradesh</option>
                         <option>karnataka</option>

                    </select>
                </div>


                <div className="row-md-3">
                    <label htmfor="inputZip" className="form-label">Zipcode</label>
                    <input type="text" className="form-control" id="inputZip" placeholder='zipcode' onChange={handleZipcode} />
                </div>

                {/* <div className="col-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck"/>
      <label class="form-check-label" for="gridCheck">
        
      </label>
    </div>
  </div> */}
                <div className="row-3">
                    <button type="submit" className="btn btn-primary">Sign in</button>
                </div>
            </form>
        </div>
    )
}

export default Register

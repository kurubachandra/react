import React ,{useState} from 'react'
import {useNavigate} from 'react-router-dom'
function Login() {
    // const [empId,setEmpId]=useState("");
    // const [empName, setEmpName] = useState("");
    // const [empRole, setEmpRole] = useState("");
    // const[empCity,setEmpCity]=useState("");
    // const[empSalary,setEmpSalary]=useState("");
    // let login=(e)=>{
    
    // }
    const [name, setName] = useState("");
    const [password, setPassword] = useState("");
    const navigate = useNavigate();
    let login = (e) => {
      e.preventDefault();
      if (name === password) {
        navigate("/dashboard");
      } else {
        alert("Invalid Username / Password.....");
      }
    };
  return (
        <div className='chandu' >
            <h1>login application</h1>
            <form>
            <div className=" col-md-3">
                    <label htmfor="exampleInputUsername" className="form-label">Username</label>
                    <input type="text" className="form-control" id="exampleInputUsername" onChange={(e)=>setName(e.target.value)}/>

                </div>
                <div className="col-md-3">
                    <label htmfor="exampleInputPassword" className="form-label">Password</label>
                    <input type="text" className="form-control" id="exampleInputPassword" onChange={(e)=>setPassword(e.target.value)}/>

                </div>

            {/* <div className="container">
                    <label htmfor="exampleInputEmployeeid" className="form-label">Employee Id</label>
                    <input type="text" className="form-control" id="exampleInputEmployeeId" onChange={(e)=>setEmpId(e.target.value)}/>

                </div>
                <div className="container">
                    <label htmfor="exampleInputEmployeeName" className="form-label">Employee Name</label>
                    <input type="text" className="form-control" id="exampleInputEmployeeId" onChange={(e)=>setEmpName(e.target.value)}/>

                </div>
                <div className="container">
                    <label htmfor="exampleInputEmployeeRole" className="form-label">EmployeeRole</label>
                    <input type="text" className="form-control" id="exampleInputPassword"  onChange={(e)=>setEmpRole(e.target.value)}/>

                </div>
                <div className="container">
                    <label htmfor="exampleInputEmployeeCity" className="form-label">Employee City</label>
                    <input type="text" className="form-control" id="exampleInputEmployeeCity" onChange={(e)=>setEmpCity(e.target.value)}/>

                </div>
                <div className="container">
                    <label htmfor="exampleInputEmployeesalary" className="form-label">Employee Salary</label>
                    <input type="text" className="form-control" id="exampleInputEmployeeId" onChange={(e)=>setEmpSalary(e.target.value)}/>

                </div> */}

               <br/> <button  className="btn btn-primary" onClick={login} style={{marginRight:'1200px'}}>Submit</button>
            </form>
            {/* {empName}
            {empRole}
            {empId}
            {empCity}
            {empSalary} */}
            {name}
            {password}
        </div>
    );
}

export default Login;

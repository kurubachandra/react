import React from 'react'
import { useState } from 'react'
function DashBoard() {
    const [id, setEmpId] = useState();
    const [name, setEmpName] = useState();
    const [role, setEmpRole] = useState();
    const [salary, setEmpSalary] = useState();
    let employee = [
        {
            "id": 1,
            "name": "chandra",
            "role": "java",
            "city": "hyd",
            "salary": 110

        },
        {
            "id": 2,
            "name": "parameshh",
            "role": "phyton",
            "city": "mumbai",
            "salary": 150

        },
        {
            "id": 3,
            "name": "raja",
            "role": "java",
            "city": "banglore",
            "salary": 750

        },
        {
            "id": 4,
            "name": "ravi",
            "role": "Sql",
            "city": "hyd",
            "salary": 840

        },
    ];
    const editEmployee = () => {
        alert("Employee edit method calling.........");
    }
    const deleteEmployee = () => {
        alert("Employee delete method calling.........");
    }
    const createEmployee = () => {

        alert("calling add employee method ............ " + JSON.stringify(newEmployee));
        const size = employee.length;
        console.log("employee array size:" + size)
        employee.push(newEmployee);
    };
    let newEmployee = {
        "id": parseInt(id),
        "name": name,
        "role": role,
        "salary": parseFloat(salary)

    }
    const employeedetails = employee.map(employee => {
        return (
            <tr key={employee.id}>
                <td>{employee.id}</td>
                <td>{employee.name}</td>
                <td>{employee.role}</td>
                <td>{employee.salary}</td>
                <td>{employee.city}</td>
                <td>
                    <button className='btn btn-primary' style={{ margin: "10px" }} onClick={editEmployee}>Edit</button>
                    <button className='btn btn-danger' onClick={deleteEmployee}>Delete</button>
                </td>
            </tr>
        )
    })
    return (
        <div className='container'>
            <h1>create Employee</h1>
            <hr />
            {/* {console.log(employee)} */}
            <form>
                <div className="mb-3">
                    <label htmfor="exampleInputEmployeeid" className="form-label">Employee Id</label>
                    <input type="number" className="form-control" id="eid" value={id} onChange={(e) => setEmpId(e.target.value)} />

                </div>
                <div className="mb-3">
                    <label htmfor="exampleInputEmployeeName" className="form-label">Employee Name</label>
                    <input type="text" className="form-control" id="ename" value={name} onChange={(e) => setEmpName(e.target.value)} />

                </div>
                <div className="mb-3">
                    <label htmfor="exampleInputEmployeeRole" className="form-label">Employee Role</label>
                    <input type="text" className="form-control" id="erole" value={role} onChange={(e) => setEmpRole(e.target.value)} />

                </div>
                <div className="mb-3">
                    <label htmfor="exampleInputEmployeesalary" className="form-label">Employee Salary</label>
                    <input type="number" className="form-control" id="esalary" value={salary} onChange={(e) => setEmpSalary(e.target.value)} />

                </div>

                <button type="submit" class="btn btn-primary" onClick={createEmployee}>create</button>
            </form>
            {id}{name}{role}{salary}
            <h1>EmployeeList</h1>
            <hr />
            <table className="table">
                <thead>
                    <tr><th scope="col">Id</th>
                        <th scope="col">Name</th>
                        <th scope="col">role</th>
                        <th scope="col">city</th>
                        <th scope="col">salary</th>
                        <th colSpan={"2"}>Actions</th>

                    </tr>
                </thead>
                <tbody>
                    {employeedetails}
                </tbody>
            </table>
        </div>

    )
}

export default DashBoard;

import axios from 'axios'
import 'jquery/dist/jquery'
//Datatable Modules

import "datatables.net-dt/js/dataTables.dataTables"
import "datatables.net-dt/css/jquery.dataTables.min.css";
import $ from "jquery";
import React, { Component } from "react";


class UsersList extends Component {

    constructor(props) {
        super(props)
        this.state = {
            data: [],
        }
    }
    componentDidMount() {
        axios.get(" http://localhost:3000/users").then(res => {
            this.setState({ data: res.data });
        });
        $(document).ready(function () {
            setTimeout(function () {
                $('#userdata').DataTable();
            }, 1000);
        });
    }
    render() {
        return (
            <div className="MainDiv">
                <div className="jumbotron text-center">
                    <h3 className='chandra'>chandratutorials.com</h3>
                </div>
                <div className='container'>
                    <table id="userdata" className="table table-hover table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">id</th>
                                <th scope="col">username</th>
                                <th scope="col">email</th>

                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.data.map((res) => {
                                    return (

                                        <tr>
                                            {/* <th scope="row">1</th> */}
                                            <td>{res.id}</td>
                                            <td>{res.username}</td>
                                            <td>{res.email}</td>
                                        </tr>
                                    )
                                }
                                )
                            }
                        </tbody>
                    </table>

                </div>
            </div>
        )
    }
}

export default UsersList
